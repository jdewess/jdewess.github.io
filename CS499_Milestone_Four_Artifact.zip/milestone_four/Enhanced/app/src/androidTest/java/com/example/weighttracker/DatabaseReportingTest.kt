package com.example.weighttracker

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DatabaseReportingTest {
    private lateinit var context: Context

    @Before fun setup() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        context.deleteDatabase("weighttracker.db")
    }

    @After fun cleanup() { context.deleteDatabase("weighttracker.db") }

    @Test fun summaryRangeAndGoalHistoryUseOnlyTheSelectedAccount() {
        val helper = WeightTrackerDbHelper(context)
        val hasher = PasswordHasher()
        val first = helper.createUser("firstuser", hasher.hash("password1"))
        val second = helper.createUser("seconduser", hasher.hash("password2"))

        helper.addWeight(first, "2026-09-01", 200.0)
        helper.addWeight(first, "2026-09-15", 195.0)
        helper.addWeight(first, "2026-09-30", 190.0)
        helper.addWeight(second, "2026-09-30", 300.0)
        helper.saveGoal(first, 180.0, "2026-09-01")
        helper.saveGoal(first, 175.0, "2026-09-20")

        val summary = helper.summary(first)
        assertEquals(3, summary.entryCount)
        assertEquals(200.0, summary.firstWeight!!, 0.0)
        assertEquals(190.0, summary.latestWeight!!, 0.0)
        assertEquals(195.0, summary.averageWeight!!, 0.0)
        assertEquals(-10.0, summary.totalChange!!, 0.0)
        assertEquals(175.0, summary.currentGoal!!, 0.0)

        val range = helper.weightsBetween(first, "2026-09-10", "2026-09-20")
        assertEquals(1, range.size)
        assertEquals(195.0, range.first().weight, 0.0)
        assertEquals(2, helper.goalHistory(first).size)
        assertTrue(helper.weights(second).none { it.weight == 190.0 })
        helper.close()
    }
}
