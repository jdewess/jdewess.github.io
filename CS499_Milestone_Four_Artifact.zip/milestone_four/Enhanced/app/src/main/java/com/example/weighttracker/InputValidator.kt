package com.example.weighttracker

import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Locale

/** Validation shared by the screens and application service. */
object InputValidator {
    fun username(value: String): String {
        val cleaned = value.trim()
        require(cleaned.length in 3..32 && cleaned.all { it.isLetterOrDigit() || it == '_' }) {
            "Username must be 3 to 32 letters, numbers, or underscores."
        }
        return cleaned
    }

    fun password(value: String) {
        require(value.length >= 8) { "Password must be at least 8 characters." }
    }

    fun weight(value: String): Double {
        val parsed = value.trim().toDoubleOrNull()
        require(parsed != null && parsed.isFinite() && parsed in 1.0..1500.0) {
            "Enter a weight between 1 and 1500 lbs."
        }
        return parsed
    }

    fun date(value: String): String {
        val cleaned = value.trim()
        val format = SimpleDateFormat("MM/dd/yyyy", Locale.US).apply { isLenient = false }
        val position = ParsePosition(0)
        val parsed = format.parse(cleaned, position)
        require(Regex("\\d{2}/\\d{2}/\\d{4}").matches(cleaned) && parsed != null &&
            position.index == cleaned.length && format.format(parsed) == cleaned) {
            "Use a real date in MM/DD/YYYY format."
        }
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(parsed)
    }

    fun displayDate(storedDate: String): String =
        if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(storedDate)) {
            "${storedDate.substring(5, 7)}/${storedDate.substring(8, 10)}/${storedDate.substring(0, 4)}"
        } else storedDate
}
