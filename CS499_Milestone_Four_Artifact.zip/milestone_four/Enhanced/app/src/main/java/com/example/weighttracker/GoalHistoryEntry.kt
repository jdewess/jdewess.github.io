package com.example.weighttracker

data class GoalHistoryEntry(
    val id: Long,
    val effectiveDate: String,
    val goal: Double
)
