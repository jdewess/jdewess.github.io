package com.example.weighttracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private lateinit var service: WeightService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        service = AppServices.weightService(this)

        val username = findViewById<EditText>(R.id.etUsername)
        val password = findViewById<EditText>(R.id.etPassword)
        val logIn = findViewById<Button>(R.id.btnLogin)
        val register = findViewById<Button>(R.id.btnCreateAccount)

        logIn.setOnClickListener {
            logIn.isEnabled = false
            register.isEnabled = false
            lifecycleScope.launch {
                try {
                    val id = service.logIn(username.text.toString(), password.text.toString())
                    if (id == null) showMessage("Invalid username or password.") else openDashboard(id)
                } catch (e: IllegalArgumentException) {
                    showMessage(e.message ?: "Check your login details.")
                } catch (e: Exception) {
                    showMessage("Login failed. Please try again.")
                } finally {
                    logIn.isEnabled = true
                    register.isEnabled = true
                }
            }
        }
        register.setOnClickListener {
            logIn.isEnabled = false
            register.isEnabled = false
            lifecycleScope.launch {
                try {
                    openDashboard(service.register(username.text.toString(), password.text.toString()))
                } catch (e: IllegalArgumentException) {
                    showMessage(e.message ?: "Check your account details.")
                } catch (e: IllegalStateException) {
                    showMessage(e.message ?: "Could not create account.")
                } catch (e: Exception) {
                    showMessage("Could not create account. Please try again.")
                } finally {
                    logIn.isEnabled = true
                    register.isEnabled = true
                }
            }
        }
    }

    private fun openDashboard(id: Long) {
        AppServices.signIn(id)
        startActivity(Intent(this, DashboardActivity::class.java))
        finish()
    }

    private fun showMessage(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
