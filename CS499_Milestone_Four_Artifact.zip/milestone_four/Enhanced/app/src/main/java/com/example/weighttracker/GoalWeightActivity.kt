package com.example.weighttracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class GoalWeightActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = AppServices.signedInUserId ?: run {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        setContentView(R.layout.activity_goal_weight)
        val service = AppServices.weightService(this)
        val input = findViewById<EditText>(R.id.etGoalWeight)
        val save = findViewById<Button>(R.id.btnSaveGoal)
        lifecycleScope.launch {
            try {
                service.goal(id)?.let { input.setText(it.toString()) }
                val history = service.goalHistory(id).take(5)
                findViewById<TextView>(R.id.tvGoalHistory).text = if (history.isEmpty()) {
                    "No previous goals."
                } else {
                    "Recent goals:\n" + history.joinToString("\n") { item ->
                        val date = if (item.effectiveDate == "1970-01-01") {
                            "Imported goal"
                        } else {
                            InputValidator.displayDate(item.effectiveDate)
                        }
                        "$date: ${item.goal} lbs"
                    }
                }
            }
            catch (e: Exception) { showMessage("Could not load your goal.") }
        }
        save.setOnClickListener {
            save.isEnabled = false
            lifecycleScope.launch {
                try { service.saveGoal(id, input.text.toString()); showMessage("Goal saved."); finish() }
                catch (e: IllegalArgumentException) { showMessage(e.message ?: "Enter a valid goal.") }
                catch (e: Exception) { showMessage("Could not save your goal.") }
                finally { save.isEnabled = true }
            }
        }
        findViewById<Button>(R.id.btnBackToDashboard).setOnClickListener { finish() }
    }
    private fun showMessage(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
