package com.example.weighttracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class AddEntryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = AppServices.signedInUserId ?: run {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        setContentView(R.layout.activity_add_entry)
        val service = AppServices.weightService(this)
        val date = findViewById<EditText>(R.id.etEntryDate)
        val weight = findViewById<EditText>(R.id.etEntryWeight)
        val save = findViewById<Button>(R.id.btnSaveEntry)
        save.setOnClickListener {
            save.isEnabled = false
            lifecycleScope.launch {
                try {
                    val value = service.addWeight(id, date.text.toString(), weight.text.toString())
                    val goal = service.goal(id)
                    if (goal != null && value <= goal) sendGoalNoticeIfAllowed()
                    showMessage("Entry saved.")
                    finish()
                } catch (e: IllegalArgumentException) {
                    showMessage(e.message ?: "Check the entry.")
                } catch (e: Exception) {
                    showMessage("Could not save the entry.")
                } finally { save.isEnabled = true }
            }
        }
        findViewById<Button>(R.id.btnCancelEntry).setOnClickListener { finish() }
    }

    private fun sendGoalNoticeIfAllowed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED) return
        try {
            // Emulator number used by the original course project. Keep weight values out of SMS.
            SmsManager.getDefault().sendTextMessage("5554", null, "You reached your goal!", null, null)
        } catch (e: Exception) { showMessage("Entry saved, but the SMS could not be sent.") }
    }

    private fun showMessage(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
