package com.example.weighttracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import java.util.Locale

class DashboardActivity : AppCompatActivity() {
    private lateinit var service: WeightService
    private lateinit var adapter: WeightAdapter
    private var userId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        userId = AppServices.signedInUserId ?: run {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        setContentView(R.layout.activity_dashboard)
        service = AppServices.weightService(this)
        val list = findViewById<RecyclerView>(R.id.rvWeightGrid)
        list.layoutManager = LinearLayoutManager(this)
        adapter = WeightAdapter(mutableListOf()) { entry ->
            lifecycleScope.launch {
                try {
                    if (service.removeWeight(userId, entry.id)) loadWeights()
                    else showMessage("Entry could not be deleted.")
                } catch (e: Exception) { showMessage("Could not delete entry.") }
            }
        }
        list.adapter = adapter
        findViewById<Button>(R.id.btnAddEntry).setOnClickListener { open(AddEntryActivity::class.java) }
        findViewById<Button>(R.id.btnSetGoal).setOnClickListener { open(GoalWeightActivity::class.java) }
        findViewById<Button>(R.id.btnSmsSettings).setOnClickListener { open(SmsSettingsActivity::class.java) }
        findViewById<Button>(R.id.btnLogOut).setOnClickListener {
            AppServices.signOut()
            startActivity(Intent(this, LoginActivity::class.java)); finish()
        }
    }

    override fun onResume() { super.onResume(); if (userId > 0) loadWeights() }

    private fun loadWeights() {
        lifecycleScope.launch {
            try {
                val entries = service.weights(userId)
                adapter.updateData(entries)
                val summary = service.summary(userId)
                val goal = summary.currentGoal
                val latest = summary.latestWeight
                findViewById<TextView>(R.id.tvProgress).text = when {
                    goal == null -> "Set a goal to see your progress."
                    latest == null -> "Add a weight entry to see your progress."
                    else -> "Latest: $latest lbs  |  Goal: $goal lbs  |  Difference: "+
                        "%.1f lbs".format(kotlin.math.abs(latest - goal))
                }
                findViewById<TextView>(R.id.tvStatistics).text = when {
                    summary.entryCount == 0 -> "No summary statistics yet."
                    else -> {
                        val average = String.format(Locale.US, "%.1f", summary.averageWeight ?: 0.0)
                        val change = String.format(Locale.US, "%+.1f", summary.totalChange ?: 0.0)
                        "Entries: ${summary.entryCount}  |  Average: $average lbs  |  " +
                            "Total change: $change lbs"
                    }
                }
            } catch (e: Exception) { showMessage("Could not load your weight data.") }
        }
    }

    private fun open(type: Class<*>) { startActivity(Intent(this, type)) }
    private fun showMessage(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
