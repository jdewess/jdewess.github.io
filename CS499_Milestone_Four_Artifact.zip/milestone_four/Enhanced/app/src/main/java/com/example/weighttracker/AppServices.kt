package com.example.weighttracker

import android.content.Context

/** The app keeps one session in memory and asks for a login after process restart. */
object AppServices {
    @Volatile var signedInUserId: Long? = null
        private set

    @Volatile private var service: WeightService? = null

    fun weightService(context: Context): WeightService =
        service ?: synchronized(this) {
            service ?: WeightService(WeightTrackerDbHelper(context.applicationContext)).also { service = it }
        }

    fun signIn(userId: Long) { signedInUserId = userId }
    fun signOut() { signedInUserId = null }
}
