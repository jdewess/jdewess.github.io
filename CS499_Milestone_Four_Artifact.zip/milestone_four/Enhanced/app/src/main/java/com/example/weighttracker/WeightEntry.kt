package com.example.weighttracker

// Simple model class for each row in the weight grid.
data class WeightEntry(
    val id: Long,
    val date: String,
    val weight: Double
)
