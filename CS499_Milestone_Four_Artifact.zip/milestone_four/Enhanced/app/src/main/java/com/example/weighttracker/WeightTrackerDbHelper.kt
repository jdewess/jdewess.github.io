package com.example.weighttracker

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/** SQLite repository with migrations, indexed history queries, and summary reporting. */
class WeightTrackerDbHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION), WeightRepository {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        createUsersTable(db)
        createWeightsTable(db)
        createGoalHistoryTable(db)
        createIndexesAndSummaryView(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) migrateVersionOneToTwo(db)
        if (oldVersion < 3) migrateVersionTwoToThree(db)
    }

    private fun createUsersTable(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)"
        )
    }

    private fun createWeightsTable(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, " +
                "date TEXT NOT NULL, " +
                "weight REAL NOT NULL CHECK(weight > 0 AND weight <= 1500))"
        )
    }

    private fun createGoalHistoryTable(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE goal_history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, " +
                "effective_date TEXT NOT NULL, " +
                "goal REAL NOT NULL CHECK(goal > 0 AND goal <= 1500))"
        )
    }

    private fun createIndexesAndSummaryView(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS idx_weights_user_date " +
                "ON weights(user_id, date DESC, id DESC)"
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS idx_goals_user_date " +
                "ON goal_history(user_id, effective_date DESC, id DESC)"
        )
        db.execSQL("DROP VIEW IF EXISTS user_weight_summary")
        db.execSQL(
            "CREATE VIEW user_weight_summary AS " +
                "SELECT u.id AS user_id, COUNT(w.id) AS entry_count, " +
                "MIN(w.weight) AS minimum_weight, " +
                "MAX(w.weight) AS maximum_weight, " +
                "AVG(w.weight) AS average_weight, " +
                "(SELECT first.weight FROM weights first " +
                " WHERE first.user_id = u.id " +
                " ORDER BY first.date ASC, first.id ASC LIMIT 1) AS first_weight, " +
                "(SELECT latest.weight FROM weights latest " +
                " WHERE latest.user_id = u.id " +
                " ORDER BY latest.date DESC, latest.id DESC LIMIT 1) AS latest_weight " +
                "FROM users u LEFT JOIN weights w ON w.user_id = u.id " +
                "GROUP BY u.id"
        )
    }

    private fun migrateVersionOneToTwo(db: SQLiteDatabase) {
        // Version one shared records between accounts. Keep the data and assign it to
        // the oldest account. If no account exists, first registration claims it.
        db.execSQL("ALTER TABLE weights ADD COLUMN user_id INTEGER REFERENCES users(id)")
        db.execSQL("UPDATE weights SET user_id = (SELECT MIN(id) FROM users)")
        db.execSQL("ALTER TABLE goal_weight RENAME TO old_goal_weight")
        db.execSQL(
            "CREATE TABLE goal_weight (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER UNIQUE REFERENCES users(id), " +
                "goal REAL NOT NULL)"
        )
        db.execSQL(
            "INSERT INTO goal_weight (user_id, goal) " +
                "SELECT (SELECT MIN(id) FROM users), goal FROM old_goal_weight"
        )
        db.execSQL("DROP TABLE old_goal_weight")
    }

    private fun migrateVersionTwoToThree(db: SQLiteDatabase) {
        // Rebuild weights to add validation and cascading account cleanup.
        db.execSQL("ALTER TABLE weights RENAME TO old_weights")
        createWeightsTable(db)
        db.execSQL(
            "INSERT INTO weights (id, user_id, date, weight) " +
                "SELECT id, user_id, date, weight FROM old_weights"
        )
        db.execSQL("DROP TABLE old_weights")

        // Convert the single current goal into a history. The placeholder date marks
        // a goal that existed before the app recorded goal dates.
        createGoalHistoryTable(db)
        db.execSQL(
            "INSERT INTO goal_history (user_id, effective_date, goal) " +
                "SELECT user_id, '1970-01-01', goal FROM goal_weight"
        )
        db.execSQL("DROP TABLE goal_weight")
        createIndexesAndSummaryView(db)
    }

    override fun createUser(username: String, passwordHash: String): Long {
        val values = ContentValues().apply {
            put("username", username)
            put("password", passwordHash)
        }
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val id = db.insertOrThrow("users", null, values)
            db.execSQL("UPDATE weights SET user_id = ? WHERE user_id IS NULL", arrayOf(id))
            db.execSQL("UPDATE goal_history SET user_id = ? WHERE user_id IS NULL", arrayOf(id))
            db.setTransactionSuccessful()
            id
        } catch (_: SQLiteConstraintException) {
            -1
        } finally {
            db.endTransaction()
        }
    }

    override fun authenticate(username: String, password: String, hasher: PasswordHasher): Long? {
        val db = writableDatabase
        db.query(
            "users", arrayOf("id", "password"), "username = ?", arrayOf(username),
            null, null, null
        ).use { cursor ->
            if (!cursor.moveToFirst()) return null
            val id = cursor.getLong(0)
            val stored = cursor.getString(1)
            if (stored.startsWith("pbkdf2_sha1:")) {
                return if (hasher.verify(password, stored)) id else null
            }
            if (!MessageDigest.isEqual(
                    stored.toByteArray(StandardCharsets.UTF_8),
                    password.toByteArray(StandardCharsets.UTF_8)
                )
            ) return null
            val values = ContentValues().apply { put("password", hasher.hash(password)) }
            check(
                db.update(
                    "users", values, "id = ? AND password = ?", arrayOf(id.toString(), stored)
                ) == 1
            ) { "Could not update password security." }
            return id
        }
    }

    override fun addWeight(userId: Long, date: String, weight: Double): Long {
        val values = ContentValues().apply {
            put("user_id", userId)
            put("date", date)
            put("weight", weight)
        }
        return writableDatabase.insert("weights", null, values)
    }

    override fun weights(userId: Long): List<WeightEntry> = queryWeights(
        selection = "user_id = ?",
        arguments = arrayOf(userId.toString())
    )

    override fun weightsBetween(
        userId: Long,
        startDate: String,
        endDate: String
    ): List<WeightEntry> = queryWeights(
        selection = "user_id = ? AND date BETWEEN ? AND ?",
        arguments = arrayOf(userId.toString(), startDate, endDate)
    )

    private fun queryWeights(selection: String, arguments: Array<String>): List<WeightEntry> {
        val result = mutableListOf<WeightEntry>()
        readableDatabase.query(
            "weights", arrayOf("id", "date", "weight"), selection, arguments,
            null, null, "date DESC, id DESC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2)))
            }
        }
        return result
    }

    override fun removeWeight(userId: Long, entryId: Long): Boolean =
        writableDatabase.delete(
            "weights", "id = ? AND user_id = ?",
            arrayOf(entryId.toString(), userId.toString())
        ) > 0

    override fun goal(userId: Long): Double? {
        readableDatabase.query(
            "goal_history", arrayOf("goal"), "user_id = ?", arrayOf(userId.toString()),
            null, null, "effective_date DESC, id DESC", "1"
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getDouble(0) else null
        }
    }

    override fun goalHistory(userId: Long): List<GoalHistoryEntry> {
        val result = mutableListOf<GoalHistoryEntry>()
        readableDatabase.query(
            "goal_history", arrayOf("id", "effective_date", "goal"),
            "user_id = ?", arrayOf(userId.toString()), null, null,
            "effective_date DESC, id DESC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(
                    GoalHistoryEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2))
                )
            }
        }
        return result
    }

    override fun saveGoal(userId: Long, goal: Double, effectiveDate: String): Boolean {
        val values = ContentValues().apply {
            put("user_id", userId)
            put("effective_date", effectiveDate)
            put("goal", goal)
        }
        return writableDatabase.insert("goal_history", null, values) > 0
    }

    override fun summary(userId: Long): WeightSummary {
        readableDatabase.query(
            "user_weight_summary",
            arrayOf(
                "entry_count", "first_weight", "latest_weight", "average_weight",
                "minimum_weight", "maximum_weight"
            ),
            "user_id = ?", arrayOf(userId.toString()), null, null, null
        ).use { cursor ->
            if (!cursor.moveToFirst()) {
                return WeightSummary(0, null, null, null, null, null, null, goal(userId))
            }
            val first = cursor.nullableDouble(1)
            val latest = cursor.nullableDouble(2)
            return WeightSummary(
                entryCount = cursor.getInt(0),
                firstWeight = first,
                latestWeight = latest,
                averageWeight = cursor.nullableDouble(3),
                minimumWeight = cursor.nullableDouble(4),
                maximumWeight = cursor.nullableDouble(5),
                totalChange = if (first != null && latest != null) latest - first else null,
                currentGoal = goal(userId)
            )
        }
    }

    private fun Cursor.nullableDouble(column: Int): Double? =
        if (isNull(column)) null else getDouble(column)

    companion object {
        private const val DATABASE_NAME = "weighttracker.db"
        private const val DATABASE_VERSION = 3
    }
}
