package com.example.weighttracker

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Versioned password encoding; the random salt is stored alongside the derived key. */
class PasswordHasher(private val random: SecureRandom = SecureRandom()) {
    fun hash(password: String): String {
        val salt = ByteArray(16).also(random::nextBytes)
        return "pbkdf2_sha1:180000:${salt.hex()}:${derive(password, salt).hex()}"
    }

    fun verify(password: String, encoded: String): Boolean {
        val parts = encoded.split(':')
        if (parts.size != 4 || parts[0] != "pbkdf2_sha1" || parts[1] != "180000") return false
        return try {
            val salt = parts[2].unhex()
            val expected = parts[3].unhex()
            salt.size == 16 && expected.size == 32 &&
                MessageDigest.isEqual(expected, derive(password, salt))
        } catch (_: IllegalArgumentException) {
            false
        }
    }

    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 180_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun ByteArray.hex() = joinToString("") { "%02x".format(it.toInt() and 0xff) }
    private fun String.unhex(): ByteArray {
        require(length % 2 == 0)
        return ByteArray(length / 2) { index ->
            substring(index * 2, index * 2 + 2).toInt(16).toByte()
        }
    }
}
