package com.example.weighttracker

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Application rules live here instead of in the Activity event listeners. */
class WeightService(private val repository: WeightRepository, private val hasher: PasswordHasher = PasswordHasher()) {
    suspend fun register(username: String, password: String): Long {
        val name = InputValidator.username(username)
        InputValidator.password(password)
        return withContext(Dispatchers.IO) {
            val id = repository.createUser(name, hasher.hash(password))
            check(id > 0) { "That username is already taken." }
            id
        }
    }

    suspend fun logIn(username: String, password: String): Long? {
        val name = username.trim()
        require(name.isNotEmpty()) { "Enter your username." }
        require(password.isNotEmpty()) { "Enter your password." }
        return withContext(Dispatchers.IO) { repository.authenticate(name, password, hasher) }
    }

    suspend fun addWeight(userId: Long, date: String, weight: String): Double {
        val validDate = InputValidator.date(date)
        val validWeight = InputValidator.weight(weight)
        return withContext(Dispatchers.IO) {
            check(repository.addWeight(userId, validDate, validWeight) > 0) { "Could not save the entry." }
            validWeight
        }
    }

    suspend fun weights(userId: Long) = withContext(Dispatchers.IO) { repository.weights(userId) }
    suspend fun weightsBetween(userId: Long, startDate: String, endDate: String): List<WeightEntry> {
        val start = InputValidator.date(startDate)
        val end = InputValidator.date(endDate)
        require(start <= end) { "The start date must be before the end date." }
        return withContext(Dispatchers.IO) { repository.weightsBetween(userId, start, end) }
    }
    suspend fun removeWeight(userId: Long, entryId: Long) = withContext(Dispatchers.IO) {
        repository.removeWeight(userId, entryId)
    }
    suspend fun goal(userId: Long) = withContext(Dispatchers.IO) { repository.goal(userId) }
    suspend fun goalHistory(userId: Long) = withContext(Dispatchers.IO) {
        repository.goalHistory(userId)
    }
    suspend fun summary(userId: Long) = withContext(Dispatchers.IO) { repository.summary(userId) }
    suspend fun saveGoal(userId: Long, text: String) {
        val validGoal = InputValidator.weight(text)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        withContext(Dispatchers.IO) {
            check(repository.saveGoal(userId, validGoal, today)) { "Could not save the goal." }
        }
    }
}
