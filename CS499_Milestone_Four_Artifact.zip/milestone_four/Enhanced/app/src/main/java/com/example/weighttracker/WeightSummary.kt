package com.example.weighttracker

data class WeightSummary(
    val entryCount: Int,
    val firstWeight: Double?,
    val latestWeight: Double?,
    val averageWeight: Double?,
    val minimumWeight: Double?,
    val maximumWeight: Double?,
    val totalChange: Double?,
    val currentGoal: Double?
)
