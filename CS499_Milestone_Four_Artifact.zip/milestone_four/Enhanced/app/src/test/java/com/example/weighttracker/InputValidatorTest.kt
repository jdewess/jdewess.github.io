package com.example.weighttracker

import org.junit.Assert.assertEquals
import org.junit.Test

class InputValidatorTest {
    @Test fun validInputsAreNormalized() {
        assertEquals("josh_1", InputValidator.username(" josh_1 "))
        assertEquals("2026-09-19", InputValidator.date(" 09/19/2026 "))
        assertEquals("09/19/2026", InputValidator.displayDate("2026-09-19"))
        assertEquals(180.5, InputValidator.weight(" 180.5 "), 0.0)
    }

    @Test fun impossibleDatesAndWeightsAreRejected() {
        listOf("02/30/2026", "2026-09-19", "9/19/2026").forEach { value ->
            try { InputValidator.date(value); throw AssertionError("Accepted $value") }
            catch (_: IllegalArgumentException) { }
        }
        listOf("NaN", "Infinity", "0", "-12", "1501").forEach { value ->
            try { InputValidator.weight(value); throw AssertionError("Accepted $value") }
            catch (_: IllegalArgumentException) { }
        }
    }
}
