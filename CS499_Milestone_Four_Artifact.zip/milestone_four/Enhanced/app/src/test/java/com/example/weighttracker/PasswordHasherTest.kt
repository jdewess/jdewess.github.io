package com.example.weighttracker

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotEquals
import org.junit.Test

class PasswordHasherTest {
    @Test fun saltedHashesVerifyOnlyTheRightPassword() {
        val hasher = PasswordHasher()
        val first = hasher.hash("my-long-password")
        val second = hasher.hash("my-long-password")
        assertNotEquals(first, second)
        assertTrue(hasher.verify("my-long-password", first))
        assertTrue(hasher.verify("my-long-password", second))
        assertFalse(hasher.verify("wrong-password", first))
        assertFalse(hasher.verify("my-long-password", "malformed"))
    }
}
