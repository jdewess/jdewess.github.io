# Database enhancement

## Schema

- `users`: account identity and password hash.
- `weights`: dated weight records linked to one user.
- `goal_history`: dated goal records linked to one user.
- `user_weight_summary`: SQL view that reports count, minimum, maximum, average, first, and latest weight for each user.

Foreign keys protect the relationships and cascade account deletion to related records. Composite indexes on `(user_id, date)` and `(user_id, effective_date)` support the most common history queries. All user-supplied values are passed through SQLite selection arguments or `ContentValues` instead of being joined into SQL strings.

## Migration

Database version 3 preserves existing data. Version 1 data first follows the version 2 account-assignment migration. Version 2 weight rows are rebuilt with validation and cascading foreign keys. The previous single goal row is copied into `goal_history` with `1970-01-01` as a marker that its original date was not available.

## User-visible changes

- The dashboard displays entry count, average weight, and total change.
- The goal screen displays up to five recent goals.
- Saving a goal adds a history record instead of overwriting the old goal.
- The repository supports parameterized date-range searches.

## Verification

Instrumentation tests cover version 1 and version 2 migration, account isolation, summary calculations, date-range queries, and goal history. Run `connectedDebugAndroidTest` in Android Studio with an emulator or test device.
