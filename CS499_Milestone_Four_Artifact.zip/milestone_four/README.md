# CS 499 Milestone Four

- `Original/` contains the Weight Tracker artifact from the earlier CS course.
- `Enhanced/` contains the cumulative CS 499 application plus the version 3 database enhancement.

Open `Enhanced/` in Android Studio. Build the application, run it on an emulator, and run `connectedDebugAndroidTest`. Create an account, add several dated weights, save more than one goal, and confirm that the dashboard statistics and recent-goal history update correctly.
