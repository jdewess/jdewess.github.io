package com.example.weighttracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Simple helper that manages all tables for the app.
class WeightTrackerDbHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        // Users table
        db.execSQL(
            """
            CREATE TABLE $TABLE_USERS (
                $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USERNAME TEXT UNIQUE NOT NULL,
                $COL_PASSWORD TEXT NOT NULL
            )
            """.trimIndent()
        )

        // Weights table
        db.execSQL(
            """
            CREATE TABLE $TABLE_WEIGHTS (
                $COL_WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_WEIGHT_DATE TEXT NOT NULL,
                $COL_WEIGHT_VALUE REAL NOT NULL
            )
            """.trimIndent()
        )

        // Goal weight table (single row)
        db.execSQL(
            """
            CREATE TABLE $TABLE_GOAL (
                $COL_GOAL_ID INTEGER PRIMARY KEY CHECK($COL_GOAL_ID = 1),
                $COL_GOAL_VALUE REAL NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_GOAL")
        onCreate(db)
    }

    // -------- User functions --------

    fun createUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_USERNAME, username)
            put(COL_PASSWORD, password)
        }
        return try {
            db.insertOrThrow(TABLE_USERS, null, values) != -1L
        } catch (e: Exception) {
            false   // likely username already exists
        }
    }

    fun validateUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            arrayOf(COL_USER_ID),
            "$COL_USERNAME = ? AND $COL_PASSWORD = ?",
            arrayOf(username, password),
            null,
            null,
            null
        )
        cursor.use {
            return it.moveToFirst()
        }
    }

    // -------- Weight entry functions --------

    fun insertWeight(date: String, weight: Double): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_WEIGHT_DATE, date)
            put(COL_WEIGHT_VALUE, weight)
        }
        return db.insert(TABLE_WEIGHTS, null, values)
    }

    fun getAllWeights(): List<WeightEntry> {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_WEIGHTS,
            arrayOf(COL_WEIGHT_ID, COL_WEIGHT_DATE, COL_WEIGHT_VALUE),
            null,
            null,
            null,
            null,
            "$COL_WEIGHT_DATE DESC" // newest first
        )

        val results = mutableListOf<WeightEntry>()
        cursor.use {
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                val date = cursor.getString(1)
                val value = cursor.getDouble(2)
                results.add(WeightEntry(id, date, value))
            }
        }
        return results
    }

    fun deleteWeight(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_WEIGHTS, "$COL_WEIGHT_ID = ?", arrayOf(id.toString()))
    }

    // -------- Goal weight functions (our "Update" example) --------

    fun setGoalWeight(goal: Double) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_GOAL_ID, 1)
            put(COL_GOAL_VALUE, goal)
        }
        // insert or replace row with id=1
        db.insertWithOnConflict(
            TABLE_GOAL,
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun getGoalWeight(): Double? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_GOAL,
            arrayOf(COL_GOAL_VALUE),
            "$COL_GOAL_ID = 1",
            null,
            null,
            null,
            null
        )
        cursor.use {
            return if (cursor.moveToFirst()) {
                cursor.getDouble(0)
            } else {
                null
            }
        }
    }

    companion object {
        private const val DATABASE_NAME = "weighttracker.db"
        private const val DATABASE_VERSION = 1

        // Users
        const val TABLE_USERS = "users"
        const val COL_USER_ID = "id"
        const val COL_USERNAME = "username"
        const val COL_PASSWORD = "password"

        // Weights
        const val TABLE_WEIGHTS = "weights"
        const val COL_WEIGHT_ID = "id"
        const val COL_WEIGHT_DATE = "date"
        const val COL_WEIGHT_VALUE = "weight"

        // Goal
        const val TABLE_GOAL = "goal_weight"
        const val COL_GOAL_ID = "id"
        const val COL_GOAL_VALUE = "goal"
    }
}
