package com.example.weighttracker

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class GoalWeightActivity : AppCompatActivity() {

    private lateinit var dbHelper: WeightTrackerDbHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal_weight)

        dbHelper = WeightTrackerDbHelper(this)

        val etGoalWeight = findViewById<EditText>(R.id.etGoalWeight)
        val btnSaveGoal = findViewById<Button>(R.id.btnSaveGoal)
        val btnBack = findViewById<Button>(R.id.btnBackToDashboard)

        // Load existing goal (if any)
        val currentGoal = dbHelper.getGoalWeight()
        if (currentGoal != null) {
            etGoalWeight.setText(currentGoal.toString())
        }

        btnSaveGoal.setOnClickListener {
            val goalText = etGoalWeight.text.toString().trim()
            val goalValue = goalText.toDoubleOrNull()

            if (goalValue == null) {
                Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            dbHelper.setGoalWeight(goalValue)
            Toast.makeText(this, "Goal weight saved.", Toast.LENGTH_SHORT).show()
        }

        btnBack.setOnClickListener {
            finish()
        }
    }
}
