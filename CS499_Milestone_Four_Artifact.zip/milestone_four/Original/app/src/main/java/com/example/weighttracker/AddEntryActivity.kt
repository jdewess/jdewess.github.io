package com.example.weighttracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class AddEntryActivity : AppCompatActivity() {

    private lateinit var dbHelper: WeightTrackerDbHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_entry)

        dbHelper = WeightTrackerDbHelper(this)

        val etDate = findViewById<EditText>(R.id.etEntryDate)
        val etWeight = findViewById<EditText>(R.id.etEntryWeight)
        val btnSave = findViewById<Button>(R.id.btnSaveEntry)
        val btnCancel = findViewById<Button>(R.id.btnCancelEntry)

        btnSave.setOnClickListener {
            val date = etDate.text.toString().trim()
            val weightText = etWeight.text.toString().trim()

            if (date.isEmpty() || weightText.isEmpty()) {
                Toast.makeText(this, "Please enter a date and weight.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val weightValue = weightText.toDoubleOrNull()
            if (weightValue == null) {
                Toast.makeText(this, "Weight must be a number.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            dbHelper.insertWeight(date, weightValue)

            // After saving, check if user reached goal weight.
            checkGoalAndSendSmsIfNeeded(weightValue)

            Toast.makeText(this, "Entry saved.", Toast.LENGTH_SHORT).show()
            finish() // go back to Dashboard
        }

        btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun checkGoalAndSendSmsIfNeeded(currentWeight: Double) {
        val goal = dbHelper.getGoalWeight() ?: return

        if (currentWeight <= goal &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                val smsManager = SmsManager.getDefault()
                val message =
                    "Congratulations! You reached your goal weight of $goal lbs. Current weight: $currentWeight lbs."
                // Emulator number example; adjust if instructor wants a specific number.
                val phoneNumber = "5554"
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            } catch (e: Exception) {
                // Fail silently so app doesn’t crash in environments without SMS.
            }
        }
    }
}
