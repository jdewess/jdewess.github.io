package com.example.weighttracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DashboardActivity : AppCompatActivity() {

    private lateinit var dbHelper: WeightTrackerDbHelper
    private lateinit var adapter: WeightAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        dbHelper = WeightTrackerDbHelper(this)

        val rvWeightGrid = findViewById<RecyclerView>(R.id.rvWeightGrid)
        val btnAddEntry = findViewById<Button>(R.id.btnAddEntry)
        val btnSetGoal = findViewById<Button>(R.id.btnSetGoal)
        val btnSmsSettings = findViewById<Button>(R.id.btnSmsSettings)

        rvWeightGrid.layoutManager = LinearLayoutManager(this)

        adapter = WeightAdapter(mutableListOf()) { entry ->
            // Delete row from DB, then refresh grid
            dbHelper.deleteWeight(entry.id)
            loadWeights()
        }
        rvWeightGrid.adapter = adapter

        btnAddEntry.setOnClickListener {
            startActivity(Intent(this, AddEntryActivity::class.java))
        }

        btnSetGoal.setOnClickListener {
            startActivity(Intent(this, GoalWeightActivity::class.java))
        }

        btnSmsSettings.setOnClickListener {
            startActivity(Intent(this, SmsSettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        loadWeights()
    }

    private fun loadWeights() {
        val weights = dbHelper.getAllWeights()
        adapter.updateData(weights)
    }
}

