package com.example.weighttracker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeightAdapter(
    private var items: MutableList<WeightEntry>,
    private val onDeleteClicked: (WeightEntry) -> Unit
) : RecyclerView.Adapter<WeightAdapter.WeightViewHolder>() {

    inner class WeightViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvRowDate)
        val tvWeight: TextView = view.findViewById(R.id.tvRowWeight)
        val btnDelete: Button = view.findViewById(R.id.btnDeleteRow)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weight_row, parent, false)
        return WeightViewHolder(view)
    }

    override fun onBindViewHolder(holder: WeightViewHolder, position: Int) {
        val item = items[position]
        holder.tvDate.text = item.date
        holder.tvWeight.text = "${item.weight} lbs"

        holder.btnDelete.setOnClickListener {
            onDeleteClicked(item)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<WeightEntry>) {
        items = newItems.toMutableList()
        notifyDataSetChanged()
    }
}
