# CS 499 Milestone Three - Algorithms and Data Structures

## Contents

- `Original/` contains the original CS 330 scene source, shaders, textures, and Visual Studio project files.
- `Enhanced/` contains the algorithms and data structures enhancement.

## Enhancement summary

The original `RenderScene` method repeated transformations, shader settings, and draw calls for every object. The enhanced version represents each object with a `SCENE_OBJECT` record stored in a vector. It uses hash maps for texture-slot, material, and object-name lookup. A stable `O(n log n)` sort groups objects by texture, material, and mesh type before an `O(n)` render traversal. The object-name index provides average `O(1)` visibility updates.

The original project uses the SNHU OpenGL starter environment and expects the course `Libraries`, `Utilities`, and `3DShapes` folders at the relative paths listed in the Visual Studio project. Those shared course dependencies were not present in the uploaded ZIP and are therefore not duplicated in this submission.

## Main enhanced files

- `Enhanced/Source/SceneManager.h`
- `Enhanced/Source/SceneManager.cpp`

Open the enhanced solution in the same CS 330 Visual Studio/OpenGL environment used for the original project. Build and run the Win32 configuration, then confirm that the desk scene still includes the counter, laptop, book, mug, mouse, and lamp.
