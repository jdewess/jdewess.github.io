///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method creates the material presets used by the scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL brushedMetalMaterial;
	brushedMetalMaterial.tag = "brushedMetalMaterial";
	brushedMetalMaterial.diffuseColor = glm::vec3(0.85f, 0.85f, 0.88f);
	brushedMetalMaterial.specularColor = glm::vec3(0.90f, 0.90f, 0.95f);
	brushedMetalMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(brushedMetalMaterial);

	OBJECT_MATERIAL darkMetalMaterial;
	darkMetalMaterial.tag = "darkMetalMaterial";
	darkMetalMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.38f);
	darkMetalMaterial.specularColor = glm::vec3(0.70f, 0.70f, 0.75f);
	darkMetalMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(darkMetalMaterial);

	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.tag = "fabricMaterial";
	fabricMaterial.diffuseColor = glm::vec3(0.95f, 0.93f, 0.88f);
	fabricMaterial.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	fabricMaterial.shininess = 8.0f;
	m_objectMaterials.push_back(fabricMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.tag = "woodMaterial";
	woodMaterial.diffuseColor = glm::vec3(0.75f, 0.62f, 0.45f);
	woodMaterial.specularColor = glm::vec3(0.20f, 0.20f, 0.18f);
	woodMaterial.shininess = 10.0f;
	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.tag = "ceramicMaterial";
	ceramicMaterial.diffuseColor = glm::vec3(0.95f, 0.94f, 0.90f);
	ceramicMaterial.specularColor = glm::vec3(0.65f, 0.65f, 0.65f);
	ceramicMaterial.shininess = 28.0f;
	m_objectMaterials.push_back(ceramicMaterial);

	OBJECT_MATERIAL screenMaterial;
	screenMaterial.tag = "screenMaterial";
	screenMaterial.diffuseColor = glm::vec3(0.18f, 0.18f, 0.20f);
	screenMaterial.specularColor = glm::vec3(0.85f, 0.85f, 0.90f);
	screenMaterial.shininess = 80.0f;
	m_objectMaterials.push_back(screenMaterial);

	OBJECT_MATERIAL bookMaterial;
	bookMaterial.tag = "bookMaterial";
	bookMaterial.diffuseColor = glm::vec3(0.80f, 0.20f, 0.18f);
	bookMaterial.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	bookMaterial.shininess = 18.0f;
	m_objectMaterials.push_back(bookMaterial);

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.tag = "plasticMaterial";
	plasticMaterial.diffuseColor = glm::vec3(0.22f, 0.22f, 0.24f);
	plasticMaterial.specularColor = glm::vec3(0.75f, 0.75f, 0.80f);
	plasticMaterial.shininess = 48.0f;
	m_objectMaterials.push_back(plasticMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method configures a warm point light near the lamp,
 *  a cool directional fill light, and disables unused lights.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setIntValue(g_UseLightingName, true);

	// Directional fill light so all objects stay visible while moving around the scene.
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.5f, -1.0f, -0.2f));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.18f, 0.18f, 0.22f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.34f, 0.34f, 0.40f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.24f, 0.24f, 0.28f));
	m_pShaderManager->setIntValue("directionalLight.bActive", true);

	// Warm point light centered inside the lamp shade.
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(3.15f, 2.10f, 0.85f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.20f, 0.16f, 0.10f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.00f, 0.88f, 0.68f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.00f, 0.95f, 0.82f));
	m_pShaderManager->setIntValue("pointLights[0].bActive", true);

	// Disable any unused point lights.
	for (int i = 1; i < 5; i++)
	{
		m_pShaderManager->setIntValue("pointLights[" + std::to_string(i) + "].bActive", false);
	}

	// Spotlight is not needed for this scene.
	m_pShaderManager->setIntValue("spotLight.bActive", false);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// initialize loaded texture count
	m_loadedTextures = 0;

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();

	// load textures
	CreateGLTexture("textures/wood_counter.jpg", "woodTexture");
	CreateGLTexture("textures/brushed_metal.jpg", "metalTexture");
	CreateGLTexture("textures/linen_fabric.jpg", "fabricTexture");
	CreateGLTexture("textures/dark_metal.jpg", "darkMetalTexture");
	CreateGLTexture("textures/aluminum.jpg", "aluminumTexture");

	// added textures
	CreateGLTexture("textures/Blue_Fabric.jpg", "blueFabric");
	CreateGLTexture("textures/Dark_plastic.jpg", "darkPlastic");
	CreateGLTexture("textures/Leather.jpg", "leatherTexture");
	CreateGLTexture("textures/Black_glitch.jpg", "glitchTexture");
	CreateGLTexture("textures/Coffee_brown.jpg", "coffeeTexture");

	// bind textures to OpenGL texture slots
	BindGLTextures();

	// build reusable material presets and configure lighting once.
	DefineObjectMaterials();
	SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setIntValue(g_UseLightingName, true);

	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Wood Counter Plane ***/
	scaleXYZ = glm::vec3(14.0f, 1.0f, 8.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("woodTexture");
	SetTextureUVScale(4.5f, 3.0f);
	SetShaderMaterial("woodMaterial");
	m_basicMeshes->DrawPlaneMesh();

	/*** Laptop Base ***/
	scaleXYZ = glm::vec3(2.2f, 0.10f, 1.45f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.10f, 0.10f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("PlasticMaterial");
	m_basicMeshes->DrawBoxMesh();

	/*** Laptop Screen ***/
	scaleXYZ = glm::vec3(2.05f, 1.35f, 0.08f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.9f, -0.48f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("glitchTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("screenMaterial");
	m_basicMeshes->DrawBoxMesh();

	/*** Laptop Hinge ***/
	scaleXYZ = glm::vec3(0.08f, 0.08f, 1.1f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(.0f, 0.18f, -0.50f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkMetalTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plasticMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Book ***/
	scaleXYZ = glm::vec3(1.25f, 0.12f, 0.95f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = -18.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.55f, 0.07f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("leatherTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("bookMaterial");
	m_basicMeshes->DrawBoxMesh();

	/*** Mug Body ***/
	scaleXYZ = glm::vec3(0.48f, 1.0f, 0.48f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-3.25f, 0.0f, 2.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("blueFabric");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Mug Coffee ***/
	scaleXYZ = glm::vec3(0.43f, 0.1f, 0.43f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-3.25f, 0.9001f, 2.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("coffeeTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Mug Handle ***/
	scaleXYZ = glm::vec3(0.14f, 0.20f, 0.14f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.78f, 0.55f, 2.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("blueFabric");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawSphereMesh();

	/*** Wireless Mouse ***/
	scaleXYZ = glm::vec3(0.30f, 0.12f, 0.48f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 18.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.05f, 0.12f, 2.50f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkMetalTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plasticMaterial");
	m_basicMeshes->DrawSphereMesh();

	/*** Lamp Base ***/
	scaleXYZ = glm::vec3(0.90f, 0.08f, 0.90f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 0.0f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metalTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("brushedMetalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Lamp Stem ***/
	scaleXYZ = glm::vec3(0.06f, 2.15f, 0.06f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 0.0f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metalTexture");
	SetTextureUVScale(1.0f, 3.5f);
	SetShaderMaterial("brushedMetalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Lamp Shade - straight drum shade ***/
	scaleXYZ = glm::vec3(1.00f, 1.10f, 1.00f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 1.75f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.96f, 0.94f, 0.90f, 1.0f);
	SetShaderMaterial("fabricMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Light Bulb / Inner Glow ***/
	scaleXYZ = glm::vec3(0.16f, 0.16f, 0.16f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 2.10f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 0.95f, 0.80f, 1.0f);
	SetShaderMaterial("fabricMaterial");
	m_basicMeshes->DrawSphereMesh();
}