///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <algorithm>
#include <tuple>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	if (m_loadedTextures >= 16 || m_textureSlotByTag.find(tag) != m_textureSlotByTag.end())
	{
		std::cout << "Texture limit reached or duplicate texture tag: " << tag << std::endl;
		return false;
	}
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			glDeleteTextures(1, &textureID);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_textureSlotByTag[tag] = m_loadedTextures;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	auto slot = m_textureSlotByTag.find(tag);
	return slot == m_textureSlotByTag.end() ? -1 : m_textureIDs[slot->second].ID;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	auto slot = m_textureSlotByTag.find(tag);
	return slot == m_textureSlotByTag.end() ? -1 : slot->second;
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	auto match = m_objectMaterials.find(tag);
	if (match == m_objectMaterials.end())
	{
		return false;
	}
	material = match->second;
	return true;
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method creates the material presets used by the scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	auto addMaterial = [this](const std::string& tag, const glm::vec3& diffuse,
		const glm::vec3& specular, float shininess)
	{
		OBJECT_MATERIAL material{ diffuse, specular, shininess, tag };
		m_objectMaterials[tag] = material;
	};

	addMaterial("brushedMetalMaterial", glm::vec3(0.85f, 0.85f, 0.88f), glm::vec3(0.90f, 0.90f, 0.95f), 64.0f);
	addMaterial("darkMetalMaterial", glm::vec3(0.35f, 0.35f, 0.38f), glm::vec3(0.70f, 0.70f, 0.75f), 64.0f);
	addMaterial("fabricMaterial", glm::vec3(0.95f, 0.93f, 0.88f), glm::vec3(0.20f, 0.20f, 0.20f), 8.0f);
	addMaterial("woodMaterial", glm::vec3(0.75f, 0.62f, 0.45f), glm::vec3(0.20f, 0.20f, 0.18f), 10.0f);
	addMaterial("ceramicMaterial", glm::vec3(0.95f, 0.94f, 0.90f), glm::vec3(0.65f, 0.65f, 0.65f), 28.0f);
	addMaterial("screenMaterial", glm::vec3(0.18f, 0.18f, 0.20f), glm::vec3(0.85f, 0.85f, 0.90f), 80.0f);
	addMaterial("bookMaterial", glm::vec3(0.80f, 0.20f, 0.18f), glm::vec3(0.35f, 0.35f, 0.35f), 18.0f);
	addMaterial("plasticMaterial", glm::vec3(0.22f, 0.22f, 0.24f), glm::vec3(0.75f, 0.75f, 0.80f), 48.0f);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method configures a warm point light near the lamp,
 *  a cool directional fill light, and disables unused lights.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setIntValue(g_UseLightingName, true);

	// Directional fill light so all objects stay visible while moving around the scene.
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.5f, -1.0f, -0.2f));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.18f, 0.18f, 0.22f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.34f, 0.34f, 0.40f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.24f, 0.24f, 0.28f));
	m_pShaderManager->setIntValue("directionalLight.bActive", true);

	// Warm point light centered inside the lamp shade.
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(3.15f, 2.10f, 0.85f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.20f, 0.16f, 0.10f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.00f, 0.88f, 0.68f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.00f, 0.95f, 0.82f));
	m_pShaderManager->setIntValue("pointLights[0].bActive", true);

	// Disable any unused point lights.
	for (int i = 1; i < 5; i++)
	{
		m_pShaderManager->setIntValue("pointLights[" + std::to_string(i) + "].bActive", false);
	}

	// Spotlight is not needed for this scene.
	m_pShaderManager->setIntValue("spotLight.bActive", false);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::AddSceneObject(const SCENE_OBJECT& sceneObject)
{
	if (m_sceneObjectIndex.find(sceneObject.name) != m_sceneObjectIndex.end())
	{
		std::cout << "Duplicate scene object name ignored: " << sceneObject.name << std::endl;
		return;
	}
	m_sceneObjectIndex[sceneObject.name] = m_sceneObjects.size();
	m_sceneObjects.push_back(sceneObject);
}

void SceneManager::SortSceneObjects()
{
	// Group objects that share texture, material, and mesh state. Stable sorting
	// keeps equal render keys in their original insertion order. Complexity is
	// O(n log n), followed by an O(n) rebuild of the name index.
	std::stable_sort(m_sceneObjects.begin(), m_sceneObjects.end(),
		[](const SCENE_OBJECT& left, const SCENE_OBJECT& right)
		{
			return std::tie(left.useTexture, left.textureTag, left.materialTag, left.meshType) <
				std::tie(right.useTexture, right.textureTag, right.materialTag, right.meshType);
		});

	m_sceneObjectIndex.clear();
	for (size_t index = 0; index < m_sceneObjects.size(); ++index)
	{
		m_sceneObjectIndex[m_sceneObjects[index].name] = index;
	}
}

bool SceneManager::SetObjectVisibility(const std::string& objectName, bool visible)
{
	auto match = m_sceneObjectIndex.find(objectName);
	if (match == m_sceneObjectIndex.end())
	{
		return false;
	}
	m_sceneObjects[match->second].visible = visible;
	return true;
}

void SceneManager::BuildSceneObjects()
{
	m_sceneObjects.clear();
	m_sceneObjectIndex.clear();
	const glm::vec4 white(1.0f);

	AddSceneObject({ "counter", MESH_TYPE::PLANE, glm::vec3(14.0f, 1.0f, 8.5f), glm::vec3(0.0f), glm::vec3(0.0f), "woodTexture", "woodMaterial", glm::vec2(4.5f, 3.0f), white, true, true });
	AddSceneObject({ "laptopBase", MESH_TYPE::BOX, glm::vec3(2.2f, 0.10f, 1.45f), glm::vec3(0.0f), glm::vec3(0.0f, 0.10f, 0.10f), "darkPlastic", "plasticMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "laptopScreen", MESH_TYPE::BOX, glm::vec3(2.05f, 1.35f, 0.08f), glm::vec3(0.0f), glm::vec3(0.0f, 0.9f, -0.48f), "glitchTexture", "screenMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "laptopHinge", MESH_TYPE::CYLINDER, glm::vec3(0.08f, 0.08f, 1.1f), glm::vec3(0.0f, 90.0f, 0.0f), glm::vec3(0.0f, 0.18f, -0.50f), "darkMetalTexture", "plasticMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "book", MESH_TYPE::BOX, glm::vec3(1.25f, 0.12f, 0.95f), glm::vec3(0.0f, -18.0f, 0.0f), glm::vec3(-2.55f, 0.07f, 0.0f), "leatherTexture", "bookMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "mugBody", MESH_TYPE::CYLINDER, glm::vec3(0.48f, 1.0f, 0.48f), glm::vec3(0.0f), glm::vec3(-3.25f, 0.0f, 2.55f), "blueFabric", "ceramicMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "mugCoffee", MESH_TYPE::CYLINDER, glm::vec3(0.43f, 0.1f, 0.43f), glm::vec3(0.0f), glm::vec3(-3.25f, 0.9001f, 2.55f), "coffeeTexture", "ceramicMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "mugHandle", MESH_TYPE::SPHERE, glm::vec3(0.14f, 0.20f, 0.14f), glm::vec3(0.0f), glm::vec3(-2.78f, 0.55f, 2.55f), "blueFabric", "ceramicMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "mouse", MESH_TYPE::SPHERE, glm::vec3(0.30f, 0.12f, 0.48f), glm::vec3(0.0f, 18.0f, 0.0f), glm::vec3(2.05f, 0.12f, 2.50f), "darkMetalTexture", "plasticMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "lampBase", MESH_TYPE::CYLINDER, glm::vec3(0.90f, 0.08f, 0.90f), glm::vec3(0.0f), glm::vec3(3.15f, 0.0f, 0.85f), "metalTexture", "brushedMetalMaterial", glm::vec2(1.0f), white, true, true });
	AddSceneObject({ "lampStem", MESH_TYPE::CYLINDER, glm::vec3(0.06f, 2.15f, 0.06f), glm::vec3(0.0f), glm::vec3(3.15f, 0.0f, 0.85f), "metalTexture", "brushedMetalMaterial", glm::vec2(1.0f, 3.5f), white, true, true });
	AddSceneObject({ "lampShade", MESH_TYPE::CYLINDER, glm::vec3(1.00f, 1.10f, 1.00f), glm::vec3(0.0f), glm::vec3(3.15f, 1.75f, 0.85f), "", "fabricMaterial", glm::vec2(1.0f), glm::vec4(0.96f, 0.94f, 0.90f, 1.0f), false, true });
	AddSceneObject({ "lightBulb", MESH_TYPE::SPHERE, glm::vec3(0.16f), glm::vec3(0.0f), glm::vec3(3.15f, 2.10f, 0.85f), "", "fabricMaterial", glm::vec2(1.0f), glm::vec4(1.0f, 0.95f, 0.80f, 1.0f), false, true });

	SortSceneObjects();
}

void SceneManager::DrawSceneObject(const SCENE_OBJECT& sceneObject)
{
	SetTransformations(sceneObject.scale, sceneObject.rotation.x, sceneObject.rotation.y,
		sceneObject.rotation.z, sceneObject.position);
	if (sceneObject.useTexture)
	{
		SetShaderTexture(sceneObject.textureTag);
		SetTextureUVScale(sceneObject.uvScale.x, sceneObject.uvScale.y);
	}
	else
	{
		SetShaderColor(sceneObject.color.r, sceneObject.color.g,
			sceneObject.color.b, sceneObject.color.a);
	}
	SetShaderMaterial(sceneObject.materialTag);

	switch (sceneObject.meshType)
	{
	case MESH_TYPE::PLANE: m_basicMeshes->DrawPlaneMesh(); break;
	case MESH_TYPE::BOX: m_basicMeshes->DrawBoxMesh(); break;
	case MESH_TYPE::CYLINDER: m_basicMeshes->DrawCylinderMesh(); break;
	case MESH_TYPE::SPHERE: m_basicMeshes->DrawSphereMesh(); break;
	case MESH_TYPE::TAPERED_CYLINDER: m_basicMeshes->DrawTaperedCylinderMesh(); break;
	}
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// initialize loaded texture count
	m_loadedTextures = 0;
	m_textureSlotByTag.clear();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();

	// load textures
	CreateGLTexture("textures/wood_counter.jpg", "woodTexture");
	CreateGLTexture("textures/brushed_metal.jpg", "metalTexture");
	CreateGLTexture("textures/linen_fabric.jpg", "fabricTexture");
	CreateGLTexture("textures/dark_metal.jpg", "darkMetalTexture");
	CreateGLTexture("textures/aluminum.jpg", "aluminumTexture");

	// added textures
	CreateGLTexture("textures/Blue_Fabric.jpg", "blueFabric");
	CreateGLTexture("textures/Dark_plastic.jpg", "darkPlastic");
	CreateGLTexture("textures/Leather.jpg", "leatherTexture");
	CreateGLTexture("textures/Black_glitch.jpg", "glitchTexture");
	CreateGLTexture("textures/Coffee_brown.jpg", "coffeeTexture");

	// bind textures to OpenGL texture slots
	BindGLTextures();

	// build reusable material presets and configure lighting once.
	DefineObjectMaterials();
	SetupSceneLights();
	BuildSceneObjects();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setIntValue(g_UseLightingName, true);

	// The scene is now rendered from its data structure rather than from one
	// hard-coded block per object. Traversal is O(n) after the one-time sort.
	for (const SCENE_OBJECT& sceneObject : m_sceneObjects)
	{
		if (sceneObject.visible)
		{
			DrawSceneObject(sceneObject);
		}
	}
	return;

#if 0 // Original inline rendering sequence retained temporarily for comparison.

	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Wood Counter Plane ***/
	scaleXYZ = glm::vec3(14.0f, 1.0f, 8.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("woodTexture");
	SetTextureUVScale(4.5f, 3.0f);
	SetShaderMaterial("woodMaterial");
	m_basicMeshes->DrawPlaneMesh();

	/*** Laptop Base ***/
	scaleXYZ = glm::vec3(2.2f, 0.10f, 1.45f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.10f, 0.10f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkPlastic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("PlasticMaterial");
	m_basicMeshes->DrawBoxMesh();

	/*** Laptop Screen ***/
	scaleXYZ = glm::vec3(2.05f, 1.35f, 0.08f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.9f, -0.48f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("glitchTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("screenMaterial");
	m_basicMeshes->DrawBoxMesh();

	/*** Laptop Hinge ***/
	scaleXYZ = glm::vec3(0.08f, 0.08f, 1.1f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(.0f, 0.18f, -0.50f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkMetalTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plasticMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Book ***/
	scaleXYZ = glm::vec3(1.25f, 0.12f, 0.95f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = -18.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.55f, 0.07f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("leatherTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("bookMaterial");
	m_basicMeshes->DrawBoxMesh();

	/*** Mug Body ***/
	scaleXYZ = glm::vec3(0.48f, 1.0f, 0.48f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-3.25f, 0.0f, 2.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("blueFabric");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Mug Coffee ***/
	scaleXYZ = glm::vec3(0.43f, 0.1f, 0.43f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-3.25f, 0.9001f, 2.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("coffeeTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Mug Handle ***/
	scaleXYZ = glm::vec3(0.14f, 0.20f, 0.14f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.78f, 0.55f, 2.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("blueFabric");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawSphereMesh();

	/*** Wireless Mouse ***/
	scaleXYZ = glm::vec3(0.30f, 0.12f, 0.48f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 18.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.05f, 0.12f, 2.50f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkMetalTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("plasticMaterial");
	m_basicMeshes->DrawSphereMesh();

	/*** Lamp Base ***/
	scaleXYZ = glm::vec3(0.90f, 0.08f, 0.90f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 0.0f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metalTexture");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("brushedMetalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Lamp Stem ***/
	scaleXYZ = glm::vec3(0.06f, 2.15f, 0.06f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 0.0f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metalTexture");
	SetTextureUVScale(1.0f, 3.5f);
	SetShaderMaterial("brushedMetalMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Lamp Shade - straight drum shade ***/
	scaleXYZ = glm::vec3(1.00f, 1.10f, 1.00f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 1.75f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.96f, 0.94f, 0.90f, 1.0f);
	SetShaderMaterial("fabricMaterial");
	m_basicMeshes->DrawCylinderMesh();

	/*** Light Bulb / Inner Glow ***/
	scaleXYZ = glm::vec3(0.16f, 0.16f, 0.16f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.15f, 2.10f, 0.85f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 0.95f, 0.80f, 1.0f);
	SetShaderMaterial("fabricMaterial");
	m_basicMeshes->DrawSphereMesh();
#endif
}
