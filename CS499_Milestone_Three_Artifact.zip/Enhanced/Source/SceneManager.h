///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <unordered_map>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager* pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

	// Mesh types are stored with each object so one rendering loop can draw
	// every object in the scene.
	enum class MESH_TYPE
	{
		PLANE,
		BOX,
		CYLINDER,
		SPHERE,
		TAPERED_CYLINDER
	};

	struct SCENE_OBJECT
	{
		std::string name;
		MESH_TYPE meshType;
		glm::vec3 scale;
		glm::vec3 rotation;
		glm::vec3 position;
		std::string textureTag;
		std::string materialTag;
		glm::vec2 uvScale;
		glm::vec4 color;
		bool useTexture;
		bool visible;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::unordered_map<std::string, OBJECT_MATERIAL> m_objectMaterials;
	// Hash maps provide average O(1) lookup instead of scanning each list.
	std::unordered_map<std::string, int> m_textureSlotByTag;
	std::unordered_map<std::string, size_t> m_sceneObjectIndex;
	std::vector<SCENE_OBJECT> m_sceneObjects;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// build reusable material definitions for scene objects
	void DefineObjectMaterials();
	// configure the scene lighting uniforms
	void SetupSceneLights();
	void BuildSceneObjects();
	void AddSceneObject(const SCENE_OBJECT& sceneObject);
	void SortSceneObjects();
	void DrawSceneObject(const SCENE_OBJECT& sceneObject);

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();
	// Name lookup uses the scene index and therefore averages O(1).
	bool SetObjectVisibility(const std::string& objectName, bool visible);

};
