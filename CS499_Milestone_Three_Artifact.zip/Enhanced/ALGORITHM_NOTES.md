# Algorithm notes

| Operation | Original approach | Enhanced approach |
| --- | --- | --- |
| Texture lookup | Linear scan, `O(t)` | Hash map, average `O(1)` |
| Material lookup | Linear scan, `O(m)` | Hash map, average `O(1)` |
| Object lookup by name | Not supported | Hash map, average `O(1)` |
| Render preparation | Hard-coded command sequence | Stable sort, `O(n log n)` |
| Per-frame traversal | Repeated blocks | One vector traversal, `O(n)` |

The enhancement uses additional memory for the three indexes. For this small scene, the speed difference is minor. The main value is that the design scales better and keeps object data separate from the drawing algorithm. Stable sorting is appropriate for the current opaque objects because it groups shared state while preserving insertion order for objects with equal keys. A future scene with transparent objects would need a separate depth-based pass instead of using this same grouping rule for every object.
