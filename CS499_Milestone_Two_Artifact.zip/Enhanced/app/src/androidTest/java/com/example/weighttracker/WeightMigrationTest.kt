package com.example.weighttracker

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WeightMigrationTest {
    private lateinit var context: Context

    @Before fun setup() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        context.deleteDatabase("weighttracker.db")
    }

    @After fun cleanup() { context.deleteDatabase("weighttracker.db") }

    @Test fun legacyDataIsPreservedAndPrivateAfterUpgrade() {
        val old = context.openOrCreateDatabase("weighttracker.db", Context.MODE_PRIVATE, null)
        old.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)")
        old.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, weight REAL NOT NULL)")
        old.execSQL("CREATE TABLE goal_weight (id INTEGER PRIMARY KEY CHECK(id = 1), goal REAL NOT NULL)")
        old.execSQL("INSERT INTO users (username, password) VALUES ('first', 'originalpass')")
        old.execSQL("INSERT INTO users (username, password) VALUES ('second', 'anotherpass')")
        old.execSQL("INSERT INTO weights (date, weight) VALUES ('2026-09-19', 180.0)")
        old.execSQL("INSERT INTO goal_weight (id, goal) VALUES (1, 170.0)")
        old.version = 1
        old.close()

        val helper = WeightTrackerDbHelper(context)
        val hasher = PasswordHasher()
        val firstId = helper.authenticate("first", "originalpass", hasher)!!
        val secondId = helper.authenticate("second", "anotherpass", hasher)!!
        assertEquals(1, helper.weights(firstId).size)
        assertEquals(170.0, helper.goal(firstId)!!, 0.0)
        assertTrue(helper.weights(secondId).isEmpty())
        assertNull(helper.goal(secondId))
        assertFalse(helper.removeWeight(secondId, helper.weights(firstId).first().id))
        assertNull(helper.authenticate("first", "wrongpass", hasher))
        helper.close()
    }

    @Test fun legacyGoalAndWeightCanBeClaimedWhenThereWasNoAccount() {
        val old = context.openOrCreateDatabase("weighttracker.db", Context.MODE_PRIVATE, null)
        old.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)")
        old.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, weight REAL NOT NULL)")
        old.execSQL("CREATE TABLE goal_weight (id INTEGER PRIMARY KEY CHECK(id = 1), goal REAL NOT NULL)")
        old.execSQL("INSERT INTO weights (date, weight) VALUES ('2026-09-19', 180.0)")
        old.execSQL("INSERT INTO goal_weight (id, goal) VALUES (1, 170.0)")
        old.version = 1
        old.close()

        val helper = WeightTrackerDbHelper(context)
        val id = helper.createUser("newuser", PasswordHasher().hash("newpassword"))
        assertTrue(id > 0)
        assertEquals(1, helper.weights(id).size)
        assertEquals(170.0, helper.goal(id)!!, 0.0)
        helper.close()
    }
}
