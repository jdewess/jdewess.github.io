package com.example.weighttracker

interface WeightRepository {
    fun createUser(username: String, passwordHash: String): Long
    fun authenticate(username: String, password: String, hasher: PasswordHasher): Long?
    fun addWeight(userId: Long, date: String, weight: Double): Long
    fun weights(userId: Long): List<WeightEntry>
    fun removeWeight(userId: Long, entryId: Long): Boolean
    fun goal(userId: Long): Double?
    fun saveGoal(userId: Long, goal: Double): Boolean
}
