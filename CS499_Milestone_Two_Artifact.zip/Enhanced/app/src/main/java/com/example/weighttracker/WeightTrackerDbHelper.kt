package com.example.weighttracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/** SQLite adapter; database reporting and goal history can expand in the next milestone. */
class WeightTrackerDbHelper(context: Context) :
    SQLiteOpenHelper(context, "weighttracker.db", null, 2), WeightRepository {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)")
        db.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id), date TEXT NOT NULL, weight REAL NOT NULL)")
        db.execSQL("CREATE TABLE goal_weight (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER UNIQUE REFERENCES users(id), goal REAL NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            // SQLiteOpenHelper already wraps this upgrade in a transaction. Legacy records
            // were shared by all accounts; assign them to the oldest account. If there
            // are no users yet, unassigned entries and goals are claimed by first registration.
            db.execSQL("ALTER TABLE weights ADD COLUMN user_id INTEGER REFERENCES users(id)")
            db.execSQL("UPDATE weights SET user_id = (SELECT MIN(id) FROM users)")
            db.execSQL("ALTER TABLE goal_weight RENAME TO old_goal_weight")
            db.execSQL("CREATE TABLE goal_weight (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER UNIQUE REFERENCES users(id), goal REAL NOT NULL)")
            db.execSQL("INSERT INTO goal_weight (user_id, goal) SELECT (SELECT MIN(id) FROM users), goal FROM old_goal_weight")
            db.execSQL("DROP TABLE old_goal_weight")
        }
    }

    override fun createUser(username: String, passwordHash: String): Long {
        val values = ContentValues().apply { put("username", username); put("password", passwordHash) }
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val id = db.insertOrThrow("users", null, values)
            db.execSQL("UPDATE weights SET user_id = ? WHERE user_id IS NULL", arrayOf(id))
            db.execSQL("UPDATE goal_weight SET user_id = ? WHERE user_id IS NULL", arrayOf(id))
            db.setTransactionSuccessful()
            id
        } catch (_: SQLiteConstraintException) {
            -1
        } finally {
            db.endTransaction()
        }
    }

    override fun authenticate(username: String, password: String, hasher: PasswordHasher): Long? {
        val db = writableDatabase
        db.query("users", arrayOf("id", "password"), "username = ?", arrayOf(username),
            null, null, null).use { cursor ->
            if (!cursor.moveToFirst()) return null
            val id = cursor.getLong(0)
            val stored = cursor.getString(1)
            if (stored.startsWith("pbkdf2_sha1:")) return if (hasher.verify(password, stored)) id else null
            // Convert a version-one plaintext password after a successful login.
            if (!MessageDigest.isEqual(stored.toByteArray(StandardCharsets.UTF_8),
                    password.toByteArray(StandardCharsets.UTF_8))) return null
            val values = ContentValues().apply { put("password", hasher.hash(password)) }
            check(db.update("users", values, "id = ? AND password = ?",
                arrayOf(id.toString(), stored)) == 1) { "Could not update password security." }
            return id
        }
    }

    override fun addWeight(userId: Long, date: String, weight: Double): Long {
        val values = ContentValues().apply {
            put("user_id", userId); put("date", date); put("weight", weight)
        }
        return writableDatabase.insert("weights", null, values)
    }

    override fun weights(userId: Long): List<WeightEntry> {
        val result = mutableListOf<WeightEntry>()
        readableDatabase.query("weights", arrayOf("id", "date", "weight"), "user_id = ?",
            arrayOf(userId.toString()), null, null, "date DESC, id DESC").use { cursor ->
            while (cursor.moveToNext()) result.add(WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2)))
        }
        return result
    }

    override fun removeWeight(userId: Long, entryId: Long): Boolean =
        writableDatabase.delete("weights", "id = ? AND user_id = ?",
            arrayOf(entryId.toString(), userId.toString())) > 0

    override fun goal(userId: Long): Double? {
        readableDatabase.query("goal_weight", arrayOf("goal"), "user_id = ?",
            arrayOf(userId.toString()), null, null, null).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getDouble(0) else null
        }
    }

    override fun saveGoal(userId: Long, goal: Double): Boolean {
        val values = ContentValues().apply { put("user_id", userId); put("goal", goal) }
        return writableDatabase.insertWithOnConflict("goal_weight", null, values,
            SQLiteDatabase.CONFLICT_REPLACE) > 0
    }
}
