package com.example.weighttracker

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Application rules live here instead of in the Activity event listeners. */
class WeightService(private val repository: WeightRepository, private val hasher: PasswordHasher = PasswordHasher()) {
    suspend fun register(username: String, password: String): Long {
        val name = InputValidator.username(username)
        InputValidator.password(password)
        return withContext(Dispatchers.IO) {
            val id = repository.createUser(name, hasher.hash(password))
            check(id > 0) { "That username is already taken." }
            id
        }
    }

    suspend fun logIn(username: String, password: String): Long? {
        val name = username.trim()
        require(name.isNotEmpty()) { "Enter your username." }
        require(password.isNotEmpty()) { "Enter your password." }
        return withContext(Dispatchers.IO) { repository.authenticate(name, password, hasher) }
    }

    suspend fun addWeight(userId: Long, date: String, weight: String): Double {
        val validDate = InputValidator.date(date)
        val validWeight = InputValidator.weight(weight)
        return withContext(Dispatchers.IO) {
            check(repository.addWeight(userId, validDate, validWeight) > 0) { "Could not save the entry." }
            validWeight
        }
    }

    suspend fun weights(userId: Long) = withContext(Dispatchers.IO) { repository.weights(userId) }
    suspend fun removeWeight(userId: Long, entryId: Long) = withContext(Dispatchers.IO) {
        repository.removeWeight(userId, entryId)
    }
    suspend fun goal(userId: Long) = withContext(Dispatchers.IO) { repository.goal(userId) }
    suspend fun saveGoal(userId: Long, text: String) {
        val validGoal = InputValidator.weight(text)
        withContext(Dispatchers.IO) {
            check(repository.saveGoal(userId, validGoal)) { "Could not save the goal." }
        }
    }
}
