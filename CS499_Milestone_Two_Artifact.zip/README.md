# CS 499 Milestone Two — Weight Tracker

- `Original/WeightTracker/`: source from the earlier Android coursework.
- `Enhanced/`: software design and engineering enhancement of that source.

The enhanced version adds a service/repository boundary, validation, account-scoped weights and goals, hashed passwords, an upgrade from the original database, dashboard progress, logout, and focused unit/instrumentation tests. The original project's emulator SMS number remains a classroom demonstration setting.

Open `Enhanced/` in Android Studio. Run `testDebugUnitTest` for local unit tests and `connectedDebugAndroidTest` on an emulator for the migration tests. An Android SDK and the project's Gradle distribution are required. In this workspace, the Gradle distribution could not be downloaded, so these tests have not yet run. The XML resource files were parsed successfully; the SQLite migration statements were exercised independently with SQLite for databases with and without existing accounts.
